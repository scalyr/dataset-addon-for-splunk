#  TA_dataset
This add-on integrates with [DataSet](https://www.dataset.com) by [SentinelOne](https://www.sentinelone.com).

For more information, see the [GitHub](https://github.com/scalyr/dataset-addon-for-splunk) repository.
##### Note
This add-on was built with the [Splunk Add-on UCC framework](https://splunk.github.io/addonfactory-ucc-generator/).
Splunk is a registered trademark of Splunk Inc. in the United States and other countries.
