#  TA_dataset
This add-on integrates with [DataSet](https://www.dataset.com) and [Singularity Data Lake](https://www.sentinelone.com/platform/xdr-ingestion) by [SentinelOne](https://www.sentinelone.com).


# Binary File Declaration
lib/charset_normalizer/md.cpython-38-x86_64-linux-gnu.so: This binary file is provided along with charset_normalizer module and source code for the same can be found at https://pypi.org/project/charset-normalizer/
lib/charset_normalizer/md__mypyc.cpython-38-x86_64-linux-gnu.so: This binary file is provided along with charset_normalizer module and source code for the same can be found at https://pypi.org/project/charset-normalizer/


For more information, see the [GitHub](https://github.com/scalyr/dataset-addon-for-splunk) repository.
##### Note
This add-on was built with the [Splunk Add-on UCC framework](https://splunk.github.io/addonfactory-ucc-generator/).
Splunk is a registered trademark of Splunk Inc. in the United States and other countries.
